BASS_MPC 2.4

� 2002-2012, Sebastian Andersson (sebastian.andersson@gmail.com). All rights reserved.
Portions � 2006, The Musepack Development Team. All rights reserved.

All trademarks and other registered names contained in the BASS_MPC
package are the property of their respective owners.


What is BASS_MPC?
=================
BASS_MPC is an extension to the BASS audio library that enables the playback
of Musepack streams.


What is Musepack?
=================
Please visit:

http://www.musepack.net


Disclaimer
==========
BASS_MPC is provided "as is" and without warranties of any kind, either express
or implied. The author assumes no liability for damages, direct or consequential,
which may result from the use of BASS_MPC.


Costs
=====
The BASS_MPC library is free to use and distribute.

If you enjoy BASS_MPC, please consider donating money. You may use PayPal to make a donation:

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sebastian%2eandersson%40gmail%2ecom&item_name=BASS%20Add%2dOns&item_number=1&no_shipping=1&no_note=1&tax=0&currency_code=EUR