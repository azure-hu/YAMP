/*
	BASSenc cast source example
	Copyright (c) 2006-2020 Un4seen Developments Ltd.
*/

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <math.h>
#include "bass.h"
#include "bassenc.h"

#ifdef USE_ADDONS // use BASSenc add-ons instead of command-line encoders
// these headers should be placed alongside bassenc.h (and the libs alongside bassenc.lib)
#include "bassenc_mp3.h"
#include "bassenc_ogg.h"
#include "bassenc_opus.h"
#include "bassenc_flac.h"
#endif

HWND win;

HRECORD rchan;		// recording channel
HENCODE encoder;	// encoder handle
int reconwait;
int titlewait;

const char *codecs[] = { "MP3", "OGG", "OPUS", "FLAC" };
DWORD bitrates[14] = { 32,40,48,56,64,80,96,112,128,160,192,224,256,320 }; // available bitrates

// display error messages
void Error(const char *es)
{
	char mes[200];
	sprintf(mes, "%s\n(error code: %d)", es, BASS_ErrorGetCode());
	MessageBox(win, mes, 0, 0);
}

// messaging macros
#define MESS(id, m, w, l) SendDlgItemMessage(win, id, m, (WPARAM)(w), (LPARAM)(l))
#define DLGITEM(id) GetDlgItem(win, id)

BOOL CALLBACK RecordingCallback(HRECORD handle, const void *buffer, DWORD length, void *user)
{
	return BASS_Encode_IsActive(handle); // continue recording if encoder is alive
}

void Start();
void Stop();

// encoder death notification
void CALLBACK EncoderNotify(HENCODE handle, DWORD status, void *user)
{
	if (status < 0x10000) { // encoder/connection died
		if (MESS(51, BM_GETCHECK, 0, 0)) {
			reconwait = 10; // trigger auto-reconnect
		} else {
			Stop(); // free the recording and encoder
			MessageBox(win, status == BASS_ENCODE_NOTIFY_CAST ? "The server connection died!" : "The encoder died!", 0, 0);
		}
	}
}

void Start()
{
	char com[200], server[100], pass[100], name[100], url[100], genre[100], desc[100], *content;
	DWORD codec, bitrate, pub;
	// start recording @ 44100hz 16-bit stereo (paused to setup encoder first)
	if (!(rchan = BASS_RecordStart(44100, 2, BASS_RECORD_PAUSE, RecordingCallback, 0))) {
		Error("Couldn't start recording");
		return;
	}
	codec = MESS(30, CB_GETCURSEL, 0, 0);
	bitrate = bitrates[MESS(31, CB_GETCURSEL, 0, 0)]; // get bitrate
	// start the encoder
#ifdef USE_ADDONS
	if (!codec) { // MP3
		sprintf(com, "-b %d", bitrate);
		encoder = BASS_Encode_MP3_Start(rchan, com, BASS_ENCODE_AUTOFREE, 0, 0);
		content = BASS_ENCODE_TYPE_MP3;
	} else if (codec == 1) { // Ogg Vorbis
		sprintf(com, "-M %d -m %d", bitrate, bitrate);
		encoder = BASS_Encode_OGG_Start(rchan, com, BASS_ENCODE_AUTOFREE, 0, 0);
		content = BASS_ENCODE_TYPE_OGG;
	} else if (codec == 2) { // Opus
		sprintf(com, "--bitrate %d --cvbr --max-delay 100 --padding 0", bitrate);
		encoder = BASS_Encode_OPUS_Start(rchan, com, BASS_ENCODE_AUTOFREE, 0, 0);
		content = BASS_ENCODE_TYPE_OGG;
	} else { // FLAC
		sprintf(com, "--ogg --no-padding --no-seektable");
		encoder = BASS_Encode_FLAC_Start(rchan, com, BASS_ENCODE_AUTOFREE, 0, 0);
		content = BASS_ENCODE_TYPE_OGG;
		bitrate = 0; // undefined bitrate
	}
#else
	// setup encoder command-line (raw PCM data to avoid WAV length limit)
	if (!codec) { // MP3
		sprintf(com, "lame -b %d --flush -r -s 44100 -", bitrate); // add "-x" for LAME versions pre-3.98
		content = BASS_ENCODE_TYPE_MP3;
	} else if (codec == 1) { // Ogg Vorbis
		sprintf(com, "oggenc -M %d -m %d -r -R 44100 -", bitrate, bitrate);
		content = BASS_ENCODE_TYPE_OGG;
	} else if (codec == 2) { // Opus
		sprintf(com, "opusenc --bitrate %d --cvbr --max-delay 100 --padding 0 --raw --raw-rate 44100 - -", bitrate);
		content = BASS_ENCODE_TYPE_OGG;
	} else { // FLAC
		sprintf(com, "flac --ogg --no-padding --no-seektable --sample-rate=44100 --channels=2 --bps=16 --endian=little --sign=signed -");
		content = BASS_ENCODE_TYPE_OGG;
		bitrate = 0; // undefined bitrate
	}
	encoder = BASS_Encode_Start(rchan, com, BASS_ENCODE_NOHEAD | BASS_ENCODE_AUTOFREE, NULL, 0);
#endif
	if (!encoder) { // failed
		Error("Couldn't start encoding");
		BASS_ChannelStop(rchan);
		rchan = 0;
		return;
	}
	// setup cast
	GetWindowText(DLGITEM(10), server, sizeof(server));
	GetWindowText(DLGITEM(11), pass, sizeof(pass));
	GetWindowText(DLGITEM(15), name, sizeof(name));
	GetWindowText(DLGITEM(16), url, sizeof(url));
	GetWindowText(DLGITEM(17), genre, sizeof(genre));
	GetWindowText(DLGITEM(18), desc, sizeof(desc));
	pub = MESS(12, BM_GETCHECK, 0, 0);
	if (!BASS_Encode_CastInit(encoder, server, pass, content, name, url, genre, desc, NULL, bitrate, pub)) {
		Error("Couldn't setup connection with server");
		BASS_ChannelStop(rchan);
		rchan = 0;
		return;
	}
	BASS_ChannelPlay(rchan, FALSE); // resume recording
	MESS(50, WM_SETTEXT, 0, "Stop");
	EnableWindow(DLGITEM(10), FALSE);
	EnableWindow(DLGITEM(11), FALSE);
	EnableWindow(DLGITEM(12), FALSE);
	EnableWindow(DLGITEM(15), FALSE);
	EnableWindow(DLGITEM(16), FALSE);
	EnableWindow(DLGITEM(17), FALSE);
	EnableWindow(DLGITEM(18), FALSE);
	EnableWindow(DLGITEM(30), FALSE);
	EnableWindow(DLGITEM(31), FALSE);
	EnableWindow(DLGITEM(40), TRUE);
	EnableWindow(DLGITEM(41), TRUE);
	BASS_Encode_SetNotify(encoder, EncoderNotify, 0); // notify of dead encoder/connection 
}

void Stop()
{
	// stop recording & encoding
	BASS_ChannelStop(rchan);
	rchan = 0;
	MESS(50, WM_SETTEXT, 0, "Start");
	EnableWindow(DLGITEM(10), TRUE);
	EnableWindow(DLGITEM(11), TRUE);
	EnableWindow(DLGITEM(12), TRUE);
	EnableWindow(DLGITEM(15), TRUE);
	EnableWindow(DLGITEM(16), TRUE);
	EnableWindow(DLGITEM(17), TRUE);
	EnableWindow(DLGITEM(18), TRUE);
	EnableWindow(DLGITEM(30), TRUE);
	EnableWindow(DLGITEM(31), TRUE);
	EnableWindow(DLGITEM(40), FALSE);
	EnableWindow(DLGITEM(41), FALSE);
	SetWindowText(win, "Cast test");
}

INT_PTR CALLBACK dialogproc(HWND h, UINT m, WPARAM w, LPARAM l)
{
	switch (m) {
		case WM_TIMER:
			{ // update the level display
				float level = 0;
				if (rchan) {
					BASS_ChannelGetLevelEx(rchan, &level, 0.1, BASS_LEVEL_MONO); // get current level
					if (level > 0) {
						level = 1 + log10(level) * 20 / 30; // convert to dB (30dB range)
						if (level < 0) level = 0;
					}
				}
				MESS(55, PBM_SETPOS, level * 100, 0);
			}
			// handle auto-reconnect
			if (reconwait) {
				if (!--reconwait) {
					Stop();
					Start();
				}
			} else if (rchan) {
				// check number of listeners
				static int updatelisten = 0;
				if (!(++updatelisten % 50)) { // only checking once every 5 seconds
					char text[50];
					const char *stats;
					int listeners = 0;
					if (stats = BASS_Encode_CastGetStats(encoder, BASS_ENCODE_STATS_ICE, NULL)) {
						const char *t = strstr(stats, "<Listeners>"); // Icecast listener count
						if (!t) t = strstr(stats, "<listeners>"); // try lowercase
						if (t) listeners = atoi(t + 11);
					} else if (stats = BASS_Encode_CastGetStats(encoder, BASS_ENCODE_STATS_SHOUT, "admin")) {
						const char *t = strstr(stats, "<CURRENTLISTENERS>"); // Shoutcast listener count
						if (t) listeners = atoi(t + 18);
					} else goto skiplisteners;
					sprintf(text, "Cast test (%d listeners)", listeners);
					SetWindowText(win, text);
				}
skiplisteners:
				if (titlewait) {
					if (!--titlewait) EnableWindow(DLGITEM(41), TRUE);
				}
			}
			break;

		case WM_COMMAND:
			switch (LOWORD(w)) {
				case IDCANCEL:
					DestroyWindow(h);
					break;
				case 50:
					reconwait = 0;
					if (!rchan)
						Start();
					else
						Stop();
					break;
				case 41:
					{ // send title update
						int codec = MESS(30, CB_GETCURSEL, 0, 0);
						char title[400];
						EnableWindow(DLGITEM(41), FALSE); // temporarily disable button to prevent too frequent updates
						GetWindowText(DLGITEM(40), title, sizeof(title));
#ifdef USE_ADDONS
						// Icecast requires Opus/FLAC title changes in new bitstreams
						if (codec == 2) { // Opus
							char title2[500];
							sprintf(title2, "--title \"%s\"", title);
							BASS_Encode_OPUS_NewStream(encoder, title2, 0);
						} else if (codec == 3) { // FLAC
							char title2[500];
							sprintf(title2, "-T \"title=%s\"", title);
							BASS_Encode_FLAC_NewStream(encoder, title2, 0);
						} else
#endif
							BASS_Encode_CastSetTitle(encoder, title, NULL);
						titlewait = 5;
					}
					break;
			}
			break;

		case WM_INITDIALOG:
			win = h;
			// setup default recording device
			if (!BASS_RecordInit(-1)) {
				Error("Can't initialize device");
				DestroyWindow(win);
			} else {
				int c;
				SetDlgItemText(win, 10, "localhost:8000/bass");
				SetDlgItemText(win, 11, "hackme");
				SetDlgItemText(win, 15, "BASSenc test stream");
				SetDlgItemText(win, 16, "http://www.un4seen.com");
				SetDlgItemText(win, 17, "test");
				for (c = 0; c < 4; c++)
					MESS(30, CB_ADDSTRING, 0, codecs[c]);
				MESS(30, CB_SETCURSEL, 0, 0); // default codec = MP3
				for (c = 0; c < 14; c++) {
					char temp[10];
					sprintf(temp, "%d", bitrates[c]);
					MESS(31, CB_ADDSTRING, 0, temp);
				}
				MESS(31, CB_SETCURSEL, 8, 0); // default bitrate = 128kbps
				SetTimer(h, 0, 100, 0); // timer to update the level display and listener count
				return 1;
			}
			break;

		case WM_DESTROY:
			// release all BASS stuff
			BASS_RecordFree();
			break;
	}
	return 0;
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion()) != BASSVERSION) {
		MessageBox(0, "An incorrect version of BASS.DLL was loaded", 0, MB_ICONERROR);
		return 0;
	}

	DialogBox(hInstance, MAKEINTRESOURCE(1000), 0, dialogproc);

	return 0;
}
