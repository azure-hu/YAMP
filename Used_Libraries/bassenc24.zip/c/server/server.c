/*
	BASSenc server example
	Copyright (c) 2011-2016 Un4seen Developments Ltd.
*/

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include "bass.h"
#include "bassenc.h"

HWND win;

HRECORD rchan=0;	// recording/encoding channel
HENCODE encoder;

DWORD bitrates[14]={32,40,48,56,64,80,96,112,128,160,192,224,256,320}; // available bitrates

// display error messages
void Error(const char *es)
{
	char mes[200];
	sprintf(mes,"%s\n(error code: %d)",es,BASS_ErrorGetCode());
	MessageBox(win,mes,0,0);
}

// messaging macros
#define MESS(id,m,w,l) SendDlgItemMessage(win,id,m,(WPARAM)(w),(LPARAM)(l))
#define DLGITEM(id) GetDlgItem(win,id)

BOOL CALLBACK RecordingCallback(HRECORD handle, const void *buffer, DWORD length, void *user)
{
	return BASS_Encode_IsActive(handle); // continue recording if encoder is alive
}

void Start();
void Stop();

// encoder death notification
void CALLBACK EncoderNotify(HENCODE handle, DWORD status, void *user)
{
	if (status<0x10000) { // encoder died
		Stop(); // free the recording and encoder
		MessageBox(win,"The encoder died!",0,0);
	}
}

// client connection/disconnection notification
BOOL CALLBACK EncodeClientProc(HENCODE handle, BOOL connect, const char *client, char *headers, void *user)
{
	char buf[100];
	if (connect) {
		// build response headers
		char *p=headers;
		p+=sprintf(p,"Content-Type: %s\r\n",MESS(30,BM_GETCHECK,0,0)?BASS_ENCODE_TYPE_MP3:BASS_ENCODE_TYPE_OGG);
		if (GetWindowText(DLGITEM(15),buf,sizeof(buf)))
			p+=sprintf(p,"icy-name:%s\r\n",buf);
		if (GetWindowText(DLGITEM(16),buf,sizeof(buf)))
			p+=sprintf(p,"icy-url:%s\r\n",buf);
		if (GetWindowText(DLGITEM(17),buf,sizeof(buf)))
			p+=sprintf(p,"icy-genre:%s\r\n",buf);
		MESS(60,LB_ADDSTRING,0,client); // add to client list
	} else { // disconnecting, remove from client list
		int i=MESS(60,LB_FINDSTRINGEXACT,-1,client);
		MESS(60,LB_DELETESTRING,i,0);
	}
	return TRUE; // allow connectiom
}

void Start()
{
	char buf[100];
	DWORD bitrate,port;
	// start recording @ 44100hz 16-bit stereo (paused to setup encoder first)
	if (!(rchan=BASS_RecordStart(44100,2,BASS_RECORD_PAUSE,&RecordingCallback,0))) {
		Error("Couldn't start recording");
		return;
	}
	bitrate=bitrates[MESS(35,CB_GETCURSEL,0,0)]; // get bitrate
	// setup encoder command-line (raw PCM data to avoid length limit)
	if (MESS(30,BM_GETCHECK,0,0)) { // MP3
		sprintf(buf,"lame -r -s 44100 -b %d -",bitrate); // add "-x" for LAME versions pre-3.98
	} else if (MESS(31,BM_GETCHECK,0,0)) { // OGG
		sprintf(buf,"oggenc -r -R 44100 -M %d -m %d -",bitrate,bitrate);
	} else { // FLAC
		sprintf(buf,"flac --ogg --sample-rate=44100 --channels=2 --bps=16 --endian=little --sign=signed -");
		bitrate=706; // assuming 50% reduction
	}
	encoder=BASS_Encode_Start(rchan,buf,BASS_ENCODE_NOHEAD|BASS_ENCODE_AUTOFREE,NULL,0); // start the encoder
	if (!encoder) { // failed
		Error("Couldn't start encoding...\n"
			"Make sure LAME.EXE, OGGENC.EXE or FLAC.EXE\n"
			"is in the same direcory as this example.");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	GetWindowText(DLGITEM(10),buf,sizeof(buf));
	// start the server with 5 second buffer (burst the full amount) and Shoutcast metadata enabled
	port=BASS_Encode_ServerInit(encoder,buf,bitrate*125*5,-1,MAKELONG(BASS_ENCODE_SERVER_META,1),EncodeClientProc,0);
	if (!port) { // failed
		Error("Couldn't start server");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	BASS_ChannelPlay(rchan,FALSE); // resume recording
	{ // update port number in display
		char *p=strchr(buf,':');
		if (!p && strchr(buf,'.')) {
			strcat(buf,":");
			p=strchr(buf,':');
		}
		sprintf(p?p+1:buf,"%d",port);
		MESS(10,WM_SETTEXT,0,buf);
	}
	MESS(50,WM_SETTEXT,0,"Stop");
	EnableWindow(DLGITEM(10),FALSE);
	EnableWindow(DLGITEM(15),FALSE);
	EnableWindow(DLGITEM(16),FALSE);
	EnableWindow(DLGITEM(17),FALSE);
	EnableWindow(DLGITEM(18),FALSE);
	EnableWindow(DLGITEM(30),FALSE);
	EnableWindow(DLGITEM(31),FALSE);
	EnableWindow(DLGITEM(32),FALSE);
	EnableWindow(DLGITEM(35),FALSE);
	EnableWindow(DLGITEM(40),TRUE);
	EnableWindow(DLGITEM(60),TRUE);
	BASS_Encode_SetNotify(encoder,EncoderNotify,0); // notify of dead encoder
}

void Stop()
{
	// stop recording & encoding
	BASS_ChannelStop(rchan);
	rchan=0;
	MESS(50,WM_SETTEXT,0,"Start");
	EnableWindow(DLGITEM(10),TRUE);
	EnableWindow(DLGITEM(15),TRUE);
	EnableWindow(DLGITEM(16),TRUE);
	EnableWindow(DLGITEM(17),TRUE);
	EnableWindow(DLGITEM(18),TRUE);
	EnableWindow(DLGITEM(30),TRUE);
	EnableWindow(DLGITEM(31),TRUE);
	EnableWindow(DLGITEM(32),TRUE);
	EnableWindow(DLGITEM(35),TRUE);
	EnableWindow(DLGITEM(40),FALSE);
	EnableWindow(DLGITEM(60),FALSE);
	MESS(60,LB_RESETCONTENT,0,0);
}

INT_PTR CALLBACK dialogproc(HWND h,UINT m,WPARAM w,LPARAM l)
{
	switch (m) {
		case WM_TIMER:
			{ // draw the level bar
				static DWORD level=0;
				HWND w=DLGITEM(55);
				HDC dc=GetWindowDC(w);
				RECT r;
				level=level>1500?level-1500:0;
				if (rchan) {
					DWORD l=BASS_ChannelGetLevel(rchan); // get current level
					if (LOWORD(l)>level) level=LOWORD(l);
					if (HIWORD(l)>level) level=HIWORD(l);
				}
				GetClientRect(w,&r);
				InflateRect(&r,-1,-1);
				r.top=r.bottom*(32768-level)/32768;
				FillRect(dc,&r,GetStockObject(WHITE_BRUSH));
				r.bottom=r.top;
				r.top=1;
				FillRect(dc,&r,GetStockObject(LTGRAY_BRUSH));
				ReleaseDC(w,dc);
			}
			break;

		case WM_COMMAND:
			switch (LOWORD(w)) {
				case IDCANCEL:
					DestroyWindow(h);
					break;
				case 40:
					if (HIWORD(w)==EN_CHANGE) {
						char title[100];
						GetWindowText((HWND)l,title,sizeof(title));
						BASS_Encode_CastSetTitle(encoder,title,NULL); // update the title metadata
					}
					break;
				case 50:
					if (!rchan)
						Start();
					else
						Stop();
					break;
				case 60:
					if (HIWORD(w)==LBN_DBLCLK) {
						char client[32];
						int i=MESS(60,LB_GETCURSEL,0,0);
						MESS(60,LB_GETTEXT,i,client);
						BASS_Encode_ServerKick(encoder,client);  // kick the selected client
					}
					break;
			}
			break;

		case WM_INITDIALOG:
			win=h;
			// initialize default recording device
			if (!BASS_RecordInit(-1)) {
				Error("Can't initialize device");
				DestroyWindow(win);
			} else {
				int c;
				SetDlgItemText(win,15,"BASSenc test stream");
				MESS(30,BM_SETCHECK,BST_CHECKED,0); // set default encoder to MP3
				for (c=0;c<14;c++) {
					char temp[10];
					sprintf(temp,"%d",bitrates[c]);
					MESS(35,CB_ADDSTRING,0,temp);
				}
				MESS(35,CB_SETCURSEL,8,0); // default bitrate = 128kbps
				SetTimer(h,0,50,0); // timer to update the level display
				return 1;
			}
			break;

		case WM_DESTROY:
			// release all BASS stuff
			BASS_RecordFree();
			break;
	}
	return 0;
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow)
{
	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
		MessageBox(0,"An incorrect version of BASS.DLL was loaded",0,MB_ICONERROR);
		return 0;
	}

	DialogBox(hInstance,(char*)1000,0,&dialogproc);

	return 0;
}
