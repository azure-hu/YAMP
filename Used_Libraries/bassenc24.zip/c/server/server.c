/*
	BASSenc server example
	Copyright (c) 2011-2020 Un4seen Developments Ltd.
*/

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>
#include <math.h>
#include "bass.h"
#include "bassenc.h"

#ifdef USE_ADDONS // use BASSenc add-ons instead of command-line encoders
// these headers should be placed alongside bassenc.h (and the libs alongside bassenc.lib)
#include "bassenc_mp3.h"
#include "bassenc_ogg.h"
#include "bassenc_opus.h"
#include "bassenc_flac.h"
#endif

HWND win;

HRECORD rchan;		// recording channel
HENCODE encoder;	// encoder handle
char icyheads[1000];
int titlewait;

const char *codecs[] = { "MP3", "OGG", "OPUS", "FLAC", "PCM" };
const DWORD bitrates[14] = { 32,40,48,56,64,80,96,112,128,160,192,224,256,320 }; // available bitrates

// display error messages
void Error(const char *es)
{
	char mes[200];
	sprintf(mes, "%s\n(error code: %d)", es, BASS_ErrorGetCode());
	MessageBox(win, mes, 0, 0);
}

// messaging macros
#define MESS(id, m, w, l) SendDlgItemMessage(win, id, m, (WPARAM)(w), (LPARAM)(l))
#define DLGITEM(id) GetDlgItem(win, id)

BOOL CALLBACK RecordingCallback(HRECORD handle, const void *buffer, DWORD length, void *user)
{
	return BASS_Encode_IsActive(handle); // continue recording if encoder is alive
}

void CALLBACK EncodeProc(
	HENCODE handle,
	DWORD channel,
	const void *buffer,
	DWORD length,
	void *user
)
{
	static FILE *fp = 0;
	if (!fp) fp = fopen("bass.ogg", "wb");
	fwrite(buffer, length, 1, fp);
}

void Start();
void Stop();

// encoder death notification
void CALLBACK EncoderNotify(HENCODE handle, DWORD status, void *user)
{
	if (status < 0x10000) { // encoder died
		Stop(); // free the recording and encoder
		MessageBox(win, "The encoder died!", 0, 0);
	}
}

// client connection/disconnection notification
BOOL CALLBACK EncodeClientProc(HENCODE handle, BOOL connect, const char *client, char *headers, void *user)
{
	if (connect) {
		strcpy(headers, icyheads); // set response headers
		MESS(60, LB_ADDSTRING, 0, client); // add to client list
	} else { // disconnecting, remove from client list
		int i = MESS(60, LB_FINDSTRINGEXACT, -1, client);
		MESS(60, LB_DELETESTRING, i, 0);
	}
	return TRUE; // allow connectiom
}

void Start()
{
	char buf[200];
	DWORD codec, bitrate, port, flags;
	// start recording @ 44100hz 16-bit stereo (paused to setup encoder first)
	if (!(rchan = BASS_RecordStart(44100, 2, BASS_RECORD_PAUSE, RecordingCallback, 0))) {
		Error("Couldn't start recording");
		return;
	}
	flags = (MESS(12, BM_GETCHECK, 0, 0) ? BASS_ENCODE_SERVER_SSL : 0);
	codec = MESS(30, CB_GETCURSEL, 0, 0);
	bitrate = bitrates[MESS(31, CB_GETCURSEL, 0, 0)]; // get bitrate
	// start the encoder
	if (codec == 4) { // PCM
		encoder = BASS_Encode_Start(rchan, NULL, BASS_ENCODE_PCM | BASS_ENCODE_AUTOFREE, 0, 0);
		bitrate = BASS_ChannelSeconds2Bytes(rchan, 1) / 125;
		flags |= BASS_ENCODE_SERVER_META;
	} else {
#ifdef USE_ADDONS
		if (!codec) { // MP3
			sprintf(buf, "-b %d", bitrate);
			encoder = BASS_Encode_MP3_Start(rchan, buf, BASS_ENCODE_AUTOFREE, 0, 0);
			flags |= BASS_ENCODE_SERVER_META;
		} else if (codec == 1) { // Ogg Vorbis
			sprintf(buf, "-M %d -m %d", bitrate, bitrate);
			encoder = BASS_Encode_OGG_Start(rchan, buf, BASS_ENCODE_AUTOFREE, 0, 0);
		} else if (codec == 2) { // Opus
			sprintf(buf, "--bitrate %d --cvbr --max-delay 100 --padding 0", bitrate);
			encoder = BASS_Encode_OPUS_Start(rchan, buf, BASS_ENCODE_AUTOFREE, 0, 0);
		} else { // FLAC
			sprintf(buf, "--ogg --no-padding --no-seektable");
			encoder = BASS_Encode_FLAC_Start(rchan, buf, BASS_ENCODE_AUTOFREE, 0, 0);
			bitrate = BASS_ChannelSeconds2Bytes(rchan, 0.5) / 125; // assuming 50% reduction
		}
#else
		// setup encoder command-line (raw PCM data to avoid length limit)
		if (!codec) { // MP3
			sprintf(buf, "lame -b %d --flush -r -s 44100 -", bitrate); // add "-x" for LAME versions pre-3.98
		} else if (codec == 1) { // Ogg Vorbis
			sprintf(buf, "oggenc -M %d -m %d -r -R 44100 -", bitrate, bitrate);
		} else if (codec == 2) { // Opus
			sprintf(buf, "opusenc --bitrate %d --cvbr --max-delay 100 --padding 0 --raw --raw-rate 44100 - -", bitrate);
		} else { // FLAC
			sprintf(buf, "flac --ogg --no-padding --no-seektable --sample-rate=44100 --channels=2 --bps=16 --endian=little --sign=signed -");
			bitrate = BASS_ChannelSeconds2Bytes(rchan, 0.5) / 125; // assuming 50% reduction
		}
		encoder = BASS_Encode_Start(rchan, buf, BASS_ENCODE_NOHEAD | BASS_ENCODE_AUTOFREE, 0, 0);
		flags |= BASS_ENCODE_SERVER_META;
#endif
	}
	if (!encoder) { // failed
		Error("Couldn't start encoding");
		BASS_ChannelStop(rchan);
		rchan = 0;
		return;
	}
	GetWindowText(DLGITEM(10), buf, sizeof(buf));
	// start the server with 5 second buffer (burst the full amount) and Shoutcast metadata enabled
	port = BASS_Encode_ServerInit(encoder, buf, bitrate * 125 * 5, -1, flags, EncodeClientProc, 0);
	if (!port) { // failed
		if (BASS_ErrorGetCode() == BASS_ERROR_SERVER_CERT)
			Error("Couldn't start server due to a certificate issue. Copy the example testcert.crt and testcert.key files alongside this EXE.");
		else
			Error("Couldn't start server");
		BASS_ChannelStop(rchan);
		rchan = 0;
		return;
	}
	{ // build stream info headers for clients
		char *p = icyheads;
		*p = 0;
		if (GetWindowText(DLGITEM(15), buf, sizeof(buf))) p += sprintf(p, "icy-name:%s\r\n", buf);
		if (GetWindowText(DLGITEM(16), buf, sizeof(buf))) p += sprintf(p, "icy-url:%s\r\n", buf);
		if (GetWindowText(DLGITEM(17), buf, sizeof(buf))) p += sprintf(p, "icy-genre:%s\r\n", buf);
	}
	BASS_ChannelPlay(rchan, FALSE); // resume recording
	{ // update port number in display
		char *path, *p;
		GetWindowText(DLGITEM(10), buf, sizeof(buf));
		path = strchr(buf, '/');
		if (path) *path++ = 0;
		p = strchr(buf, ':');
		if (port != atoi(p ? p + 1 : buf)) {
			char newbuf[200];
			strcpy(newbuf, buf);
			if (!p && strchr(newbuf, '.')) strcat(newbuf, ":");
			p = strchr(newbuf, ':');
			if (path)
				sprintf(p ? p + 1 : newbuf, "%d/%s", port, path);
			else
				sprintf(p ? p + 1 : newbuf, "%d", port);
			MESS(10, WM_SETTEXT, 0, newbuf);
		}
	}
	MESS(50, WM_SETTEXT, 0, "Stop");
	EnableWindow(DLGITEM(10), FALSE);
	EnableWindow(DLGITEM(11), FALSE);
	EnableWindow(DLGITEM(12), FALSE);
	EnableWindow(DLGITEM(15), FALSE);
	EnableWindow(DLGITEM(16), FALSE);
	EnableWindow(DLGITEM(17), FALSE);
	EnableWindow(DLGITEM(18), FALSE);
	EnableWindow(DLGITEM(30), FALSE);
	EnableWindow(DLGITEM(31), FALSE);
	EnableWindow(DLGITEM(40), TRUE);
	EnableWindow(DLGITEM(41), TRUE);
	EnableWindow(DLGITEM(60), TRUE);
	EnableWindow(DLGITEM(61), TRUE);
	BASS_Encode_SetNotify(encoder, EncoderNotify, 0); // notify of dead encoder
}

void Stop()
{
	// stop recording & encoding
	BASS_ChannelStop(rchan);
	rchan = 0;
	MESS(50, WM_SETTEXT, 0, "Start");
	EnableWindow(DLGITEM(10), TRUE);
	EnableWindow(DLGITEM(11), TRUE);
	EnableWindow(DLGITEM(12), TRUE);
	EnableWindow(DLGITEM(15), TRUE);
	EnableWindow(DLGITEM(16), TRUE);
	EnableWindow(DLGITEM(17), TRUE);
	EnableWindow(DLGITEM(18), TRUE);
	EnableWindow(DLGITEM(30), TRUE);
	EnableWindow(DLGITEM(31), TRUE);
	EnableWindow(DLGITEM(40), FALSE);
	EnableWindow(DLGITEM(41), FALSE);
	EnableWindow(DLGITEM(60), FALSE);
	EnableWindow(DLGITEM(61), FALSE);
	MESS(60, LB_RESETCONTENT, 0, 0);
}

INT_PTR CALLBACK dialogproc(HWND h, UINT m, WPARAM w, LPARAM l)
{
	switch (m) {
		case WM_TIMER:
			{ // update the level display
				float level = 0;
				if (rchan) {
					BASS_ChannelGetLevelEx(rchan, &level, 0.1, BASS_LEVEL_MONO); // get current level
					if (level > 0) {
						level = 1 + log10(level) * 20 / 30; // convert to dB (30dB range)
						if (level < 0) level = 0;
					}
				}
				MESS(55, PBM_SETPOS, level * 100, 0);
			}
			if (rchan && titlewait) {
				if (!--titlewait) EnableWindow(DLGITEM(41), TRUE);
			}
			break;

		case WM_COMMAND:
			switch (LOWORD(w)) {
				case IDCANCEL:
					DestroyWindow(h);
					break;
				case 41:
					{ // send title update
#ifdef USE_ADDONS
						int codec = MESS(30, CB_GETCURSEL, 0, 0);
#endif
						char title[400];
						EnableWindow(DLGITEM(41), FALSE); // temporarily disable button to prevent too frequent updates
						GetWindowText(DLGITEM(40), title, sizeof(title));
#ifdef USE_ADDONS
						// use a new bitstream for title changes with Ogg-based formats
						if (codec == 1) { // Ogg Vorbis
							char title2[500];
							sprintf(title2, "--title \"%s\"", title);
							BASS_Encode_OGG_NewStream(encoder, title2, 0);
						} else if (codec == 2) { // Opus
							char title2[500];
							sprintf(title2, "--title \"%s\"", title);
							BASS_Encode_OPUS_NewStream(encoder, title2, 0);
						} else if (codec == 3) { // FLAC
							char title2[500];
							sprintf(title2, "-T \"title=%s\"", title);
							BASS_Encode_FLAC_NewStream(encoder, title2, 0);
						} else
#endif
							BASS_Encode_CastSetTitle(encoder, title, NULL);
						titlewait = 5;
					}
					break;
				case 50:
					if (!rchan)
						Start();
					else
						Stop();
					break;
				case 61:
					{ // kick the selected client
						int i = MESS(60, LB_GETCURSEL, 0, 0);
						if (i >= 0) {
							char client[32];
							MESS(60, LB_GETTEXT, i, client);
							BASS_Encode_ServerKick(encoder, client);
						}
					}
					break;
			}
			break;

		case WM_INITDIALOG:
			win = h;
			// initialize default recording device
			if (!BASS_RecordInit(-1)) {
				Error("Can't initialize device");
				DestroyWindow(win);
			} else {
				int c;
				SetDlgItemText(win, 15, "BASSenc test stream");
				for (c = 0; c < 5; c++)
					MESS(30, CB_ADDSTRING, 0, codecs[c]);
				MESS(30, CB_SETCURSEL, 0, 0); // default codec = MP3
				for (c = 0; c < 14; c++) {
					char temp[10];
					sprintf(temp, "%d", bitrates[c]);
					MESS(31, CB_ADDSTRING, 0, temp);
				}
				MESS(31, CB_SETCURSEL, 8, 0); // default bitrate = 128kbps
				SetTimer(h, 0, 100, 0); // timer to update the level display
				return 1;
			}
			break;

		case WM_DESTROY:
			// release all BASS stuff
			BASS_RecordFree();
			break;
}
	return 0;
}

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion()) != BASSVERSION) {
		MessageBox(0, "An incorrect version of BASS.DLL was loaded", 0, MB_ICONERROR);
		return 0;
	}

	// example SSL certificate for HTTPS
	BASS_SetConfigPtr(BASS_CONFIG_ENCODE_SERVER_CERT, "testcert.crt");
	BASS_SetConfigPtr(BASS_CONFIG_ENCODE_SERVER_KEY, "testcert.key");

	BASS_GetConfigPtr(BASS_CONFIG_ENCODE_SERVER_CERT | BASS_UNICODE);

	DialogBox(hInstance, MAKEINTRESOURCE(1000), 0, dialogproc);

	return 0;
}
