/*
	BASSenc transcoding example
	Copyright (c) 2003-2020 Un4seen Developments Ltd.
*/

#include <stdlib.h>
#include <stdio.h>
#include "bass.h"
#include "bassenc.h"

#ifdef USE_ADDONS // use BASSenc add-ons instead of command-line encoders
// these headers should be placed alongside bassenc.h (and the libs alongside bassenc.lib on Windows)
#include "bassenc_mp3.h"
#include "bassenc_ogg.h"
#include "bassenc_opus.h"
#include "bassenc_flac.h"
#endif

#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#define snprintf _snprintf
#else
#include <sys/types.h>
#include <sys/time.h>
#include <termios.h>
#include <string.h>
#include <unistd.h>
#include <glob.h>

int _kbhit()
{
	int r;
	fd_set rfds;
	struct timeval tv = { 0 };
	struct termios term, oterm;
	tcgetattr(0, &oterm);
	memcpy(&term, &oterm, sizeof(term));
	cfmakeraw(&term);
	tcsetattr(0, TCSANOW, &term);
	FD_ZERO(&rfds);
	FD_SET(0, &rfds);
	r = select(1, &rfds, NULL, NULL, &tv);
	tcsetattr(0, TCSANOW, &oterm);
	return r;
}
#endif

#if __APPLE__
#define ENCODERS 8
#else
#define ENCODERS 6
#endif
// encoder output files
const char *files[ENCODERS] = {
	"bass.wav", "bass.aif", "bass.mp3", "bass.ogg", "bass.opus", "bass.flac",
#if __APPLE__
	 "bass.mp4", "bass.m4a"
#endif
};

// display error messages
void Error(const char *text)
{
	printf("Error(%d): %s\n", BASS_ErrorGetCode(), text);
	BASS_Free();
	exit(0);
}

void main(int argc, char **argv)
{
	DWORD chan, encoder;
	QWORD len, pos;
	int filep, enc = 0;
	char opts[1000] = "";

	printf("BASSenc transcoding example\n"
		"---------------------------\n");

	for (filep = 1; filep < argc; filep++) {
		if (!strncmp(argv[filep], "-e", 2))
			enc = atoi(argv[filep] + 2);
		else
			break;
	}
	if (filep == argc || enc >= ENCODERS) {
		printf("usage: convert [-e#] <file> [encoder options]\n"
#ifdef USE_ADDONS
#if __APPLE__
			"-e = encoder: 0=wav, 1=aiff, 2=mp3, 3=ogg, 4=opus, 5=flac, 6=aac, 7=alac\n");
#else
			"-e = encoder: 0=wav, 1=aiff, 2=mp3, 3=ogg, 4=opus, 5=flac\n");
#endif
#else
#if __APPLE__
			"-e = encoder: 0=wav, 1=aiff, 2=lame, 3=oggenc, 4=opusenc, 5=flac, 6=aac, 7=alac\n");
#else
			"-e = encoder: 0=wav, 1=aiff, 2=lame, 3=oggenc, 4=opusenc, 5=flac\n");
#endif
#endif
		return;
	}

	// initialize "no sound" device
	if (!BASS_Init(0, 44100, 0, 0, NULL))
		Error("Can't initialize BASS");

	// load plugins for additional input format support
#ifdef _WIN32
	{
		WIN32_FIND_DATA fd;
		HANDLE fh;
		fh = FindFirstFile("bass*.dll", &fd);
		if (fh != INVALID_HANDLE_VALUE) {
			int c = 0;
			do {
				if (BASS_PluginLoad(fd.cFileName, 0)) {
					if (!c++) printf("plugins:");
					printf(" %s", fd.cFileName);
				}
			} while (FindNextFile(fh, &fd));
			if (c) printf("\n");
			FindClose(fh);
		}
	}
#else
	{
		glob_t g;
#ifdef __APPLE__
		if (!glob("libbass*.dylib", 0, 0, &g)) {
#else
		if (!glob("libbass*.so", 0, 0, &g)) {
#endif
			int a, c = 0;
			for (a = 0; a < g.gl_pathc; a++) {
				if (BASS_PluginLoad(g.gl_pathv[a], 0)) {
					if (!c++) printf("plugins:");
					printf(" %s", g.gl_pathv[a]);
				}
			}
			if (c) printf("\n");
		}
		globfree(&g);
	}
#endif

	if (strstr(argv[filep], "://")) {
		// try streaming the URL
		chan = BASS_StreamCreateURL(argv[filep], 0, BASS_STREAM_DECODE | BASS_STREAM_BLOCK, 0, 0);
	} else {
		// try streaming the file
		chan = BASS_StreamCreateFile(FALSE, argv[filep], 0, 0, BASS_STREAM_DECODE);
		if (!chan && BASS_ErrorGetCode() == BASS_ERROR_FILEFORM) {
			// try MOD formats
			chan = BASS_MusicLoad(FALSE, argv[filep], 0, 0, BASS_MUSIC_DECODE | BASS_MUSIC_RAMPS | BASS_MUSIC_PRESCAN, 0);
		}
	}
	if (!chan) Error("Can't handle the file");

	len = BASS_ChannelGetLength(chan, BASS_POS_BYTE);

	// get encoder options
	if (filep < argc) {
		int a, c = 0;
		for (a = filep + 1; a < argc; a++) {
			char *p = argv[a];
			if (strpbrk(p, " \"")) {
				// need to put the option in quotes
				opts[c++] = '\"';
				while (*p) {
					if (c > sizeof(opts) - 3) Error("The options are too long");
					if (*p == '\"') opts[c++] = '\\';
					opts[c++] = *p;
					p++;
				}
				if (c > sizeof(opts) - 3) Error("The options are too long");
				opts[c++] = '\"';
			} else {
				int len = strlen(p);
				if (c + len > sizeof(opts) - 3) Error("The options are too long");
				strcpy(opts + c, p);
				c += len;
			}
			opts[c++] = ' ';
		}
		if (c) opts[c - 1] = 0;
	}

	printf("output: %s\n", files[enc]);
	// start the encoder
	if (!enc) // WAV
		encoder = BASS_Encode_Start(chan, files[enc], BASS_ENCODE_PCM, NULL, 0);
	else if (enc == 1) // AIFF
		encoder = BASS_Encode_Start(chan, files[enc], BASS_ENCODE_PCM | BASS_ENCODE_AIFF, NULL, 0);
	else
#if __APPLE__
	if (enc == 6) // AAC
		encoder = BASS_Encode_StartCAFile(chan, 'mp4f', 'aac ', 0, 0, files[enc]);
	else if (enc == 7) // ALAC
		encoder = BASS_Encode_StartCAFile(chan, 'm4af', 'alac', 0, 0, files[enc]);
	else
#endif
#ifdef USE_ADDONS
	if (enc == 2) // MP3
		encoder = BASS_Encode_MP3_StartFile(chan, opts, 0, files[enc]);
	else if (enc == 3) // Ogg Vorbis
		encoder = BASS_Encode_OGG_StartFile(chan, opts, 0, files[enc]);
	else if (enc == 4) // Opus
		encoder = BASS_Encode_OPUS_StartFile(chan, opts, 0, files[enc]);
	else // FLAC
		encoder = BASS_Encode_FLAC_StartFile(chan, opts, 0, files[enc]);
#else
	{
		char com[1100];
		if (enc == 2) // MP3
			sprintf(com, "lame %s - bass.mp3", opts);
		else if (enc == 3) // Ogg Vorbis
			sprintf(com, "oggenc %s -o bass.ogg -", opts);
		else if (enc == 4) // Opus
			sprintf(com, "opusenc %s - bass.opus", opts);
		else // FLAC
			sprintf(com, "flac %s -f -o bass.flac -", opts);
		printf("running: %s\n", com);
		encoder = BASS_Encode_Start(chan, com, 0, NULL, 0);
	}
#endif
	if (!encoder) Error("Can't start the encoder");

	// processing loop
	while (!_kbhit()) {
		char buf[20000];
		if (!BASS_Encode_IsActive(chan)) {
			printf("Error: The encoder died!");
			break;
		}
		if (BASS_ChannelGetData(chan, buf, sizeof(buf)) == (DWORD)-1) break;
		pos = BASS_ChannelGetPosition(chan, BASS_POS_BYTE);
		printf("done: %lld / %lld\r", pos, len);
		fflush(stdout);
	}
	printf("\n");

	BASS_Encode_Stop(chan);
	BASS_Free();
}
