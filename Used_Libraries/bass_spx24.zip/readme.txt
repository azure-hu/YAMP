BASS_SPX 2.4

� 2002-2012, Sebastian Andersson (sebastian.andersson@gmail.com). All rights reserved.
Portions � 2002-2006, Jean-Marc Valin, Xiph.Org Foundation. All rights reserved.

All trademarks and other registered names contained in the BASS_SPX
package are the property of their respective owners.


What is BASS_SPX?
=================
BASS_SPX is an extension to the BASS audio library that enables the playback
of Speex streams.


What is Speex?
==============
Please visit:

http://www.speex.org


Disclaimer
==========
BASS_SPX is provided "as is" and without warranties of any kind, either express
or implied. The author assumes no liability for damages, direct or consequential,
which may result from the use of BASS_SPX.


Costs
=====
The BASS_SPX library is free to use and distribute as long as you follow the guidelines
of the Speex license:

http://www.xiph.org/licenses/bsd/speex/

If you enjoy BASS_SPX, please consider donating money. You may use PayPal to make a donation:

https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=sebastian%2eandersson%40gmail%2ecom&item_name=BASS%20Add%2dOns&item_number=1&no_shipping=1&no_note=1&tax=0&currency_code=EUR